#include "BleCombo.h"

#if defined(USE_NIMBLE)
#include <NimBLEDevice.h>
#include <NimBLEServer.h>
#include <NimBLEUtils.h>
#include <NimBLEHIDDevice.h>
#else
// #include <BLEDevice.h>
// #include <BLEUtils.h>
// #include <BLEServer.h>
// #include "BLE2902.h"
// #include "BLEHIDDevice.h"
#endif

#include "HIDTypes.h"
#include <driver/adc.h>
#include "sdkconfig.h"

#if defined(CONFIG_ARDUHAL_ESP_LOG)
  #include "esp32-hal-log.h"
  #define LOG_TAG ""
#else
  #include "esp_log.h"
  static const char* LOG_TAG = "BLEDevice";
#endif

#define KEYBOARD_ID 0x01
#define MEDIA_KEYS_ID 0x02
#define MOUSE_ID 0x03

static const uint8_t _hidReportDescriptor[] = {
  USAGE_PAGE(1),      0x01,          // USAGE_PAGE (Generic Desktop Ctrls)
  USAGE(1),           0x06,          // USAGE (Keyboard)
  COLLECTION(1),      0x01,          // COLLECTION (Application)
  REPORT_ID(1),       KEYBOARD_ID,   //   REPORT_ID (1)
  USAGE_PAGE(1),      0x07,          //   USAGE_PAGE (Kbrd/Keypad)
  USAGE_MINIMUM(1),   0xE0,          //   USAGE_MINIMUM (0xE0)
  USAGE_MAXIMUM(1),   0xE7,          //   USAGE_MAXIMUM (0xE7)
  LOGICAL_MINIMUM(1), 0x00,          //   LOGICAL_MINIMUM (0)
  LOGICAL_MAXIMUM(1), 0x01,          //   Logical Maximum (1)
  REPORT_SIZE(1),     0x01,          //   REPORT_SIZE (1)
  REPORT_COUNT(1),    0x08,          //   REPORT_COUNT (8)
  HIDINPUT(1),        0x02,          //   INPUT (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
  REPORT_COUNT(1),    0x01,          //   REPORT_COUNT (1) ; 1 byte (Reserved)
  REPORT_SIZE(1),     0x08,          //   REPORT_SIZE (8)
  HIDINPUT(1),        0x01,          //   INPUT (Const,Array,Abs,No Wrap,Linear,Preferred State,No Null Position)
  REPORT_COUNT(1),    0x05,          //   REPORT_COUNT (5) ; 5 bits (Num lock, Caps lock, Scroll lock, Compose, Kana)
  REPORT_SIZE(1),     0x01,          //   REPORT_SIZE (1)
  USAGE_PAGE(1),      0x08,          //   USAGE_PAGE (LEDs)
  USAGE_MINIMUM(1),   0x01,          //   USAGE_MINIMUM (0x01) ; Num Lock
  USAGE_MAXIMUM(1),   0x05,          //   USAGE_MAXIMUM (0x05) ; Kana
  HIDOUTPUT(1),       0x02,          //   OUTPUT (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
  REPORT_COUNT(1),    0x01,          //   REPORT_COUNT (1) ; 3 bits (Padding)
  REPORT_SIZE(1),     0x03,          //   REPORT_SIZE (3)
  HIDOUTPUT(1),       0x01,          //   OUTPUT (Const,Array,Abs,No Wrap,Linear,Preferred State,No Null Position,Non-volatile)
  REPORT_COUNT(1),    0x06,          //   REPORT_COUNT (6) ; 6 bytes (Keys)
  REPORT_SIZE(1),     0x08,          //   REPORT_SIZE(8)
  LOGICAL_MINIMUM(1), 0x00,          //   LOGICAL_MINIMUM(0)
  LOGICAL_MAXIMUM(1), 0x65,          //   LOGICAL_MAXIMUM(0x65) ; 101 keys
  USAGE_PAGE(1),      0x07,          //   USAGE_PAGE (Kbrd/Keypad)
  USAGE_MINIMUM(1),   0x00,          //   USAGE_MINIMUM (0)
  USAGE_MAXIMUM(1),   0x65,          //   USAGE_MAXIMUM (0x65)
  HIDINPUT(1),        0x00,          //   INPUT (Data,Array,Abs,No Wrap,Linear,Preferred State,No Null Position)
  END_COLLECTION(0),                 // END_COLLECTION
  
  USAGE_PAGE(1),      0x0C,          // USAGE_PAGE (Consumer)
  USAGE(1),           0x01,          // USAGE (Consumer Control)
  COLLECTION(1),      0x01,          // COLLECTION (Application)
  REPORT_ID(1),       MEDIA_KEYS_ID, //   REPORT_ID (3)
  USAGE_PAGE(1),      0x0C,          //   USAGE_PAGE (Consumer)
  LOGICAL_MINIMUM(1), 0x00,          //   LOGICAL_MINIMUM (0)
  LOGICAL_MAXIMUM(1), 0x01,          //   LOGICAL_MAXIMUM (1)
  REPORT_SIZE(1),     0x01,          //   REPORT_SIZE (1)
  REPORT_COUNT(1),    0x10,          //   REPORT_COUNT (16)
  USAGE(1),           0xB5,          //   USAGE (Scan Next Track)     ; bit 0: 1
  USAGE(1),           0xB6,          //   USAGE (Scan Previous Track) ; bit 1: 2
  USAGE(1),           0xB7,          //   USAGE (Stop)                ; bit 2: 4
  USAGE(1),           0xCD,          //   USAGE (Play/Pause)          ; bit 3: 8
  USAGE(1),           0xE2,          //   USAGE (Mute)                ; bit 4: 16
  USAGE(1),           0xE9,          //   USAGE (Volume Increment)    ; bit 5: 32
  USAGE(1),           0xEA,          //   USAGE (Volume Decrement)    ; bit 6: 64
  USAGE(2),           0x23, 0x02,    //   Usage (WWW Home)            ; bit 7: 128
  USAGE(2),           0x94, 0x01,    //   Usage (My Computer) ; bit 0: 1
  USAGE(2),           0x92, 0x01,    //   Usage (Calculator)  ; bit 1: 2
  USAGE(2),           0x2A, 0x02,    //   Usage (WWW fav)     ; bit 2: 4
  USAGE(2),           0x21, 0x02,    //   Usage (WWW search)  ; bit 3: 8
  USAGE(2),           0x26, 0x02,    //   Usage (WWW stop)    ; bit 4: 16
  USAGE(2),           0x24, 0x02,    //   Usage (WWW back)    ; bit 5: 32
  USAGE(2),           0x83, 0x01,    //   Usage (Media sel)   ; bit 6: 64
  USAGE(2),           0x8A, 0x01,    //   Usage (Mail)        ; bit 7: 128
  HIDINPUT(1),        0x02,          //   INPUT (Data,Var,Abs,No Wrap,Linear,Preferred State,No Null Position)
  END_COLLECTION(0),                 // END_COLLECTION

  USAGE_PAGE(1),       0x01,         // USAGE_PAGE (Generic Desktop)
  USAGE(1),            0x02,         // USAGE (Mouse)
  COLLECTION(1),       0x01,         // COLLECTION (Application)
  USAGE(1),            0x01,         //   USAGE (Pointer)
  COLLECTION(1),       0x00,         //   COLLECTION (Physical)
  REPORT_ID(1),        MOUSE_ID,     //     REPORT_ID (1)
  USAGE_PAGE(1),       0x09,         //     USAGE_PAGE (Button)
  USAGE_MINIMUM(1),    0x01,         //     USAGE_MINIMUM (Button 1)
  USAGE_MAXIMUM(1),    0x05,         //     USAGE_MAXIMUM (Button 5)
  LOGICAL_MINIMUM(1),  0x00,         //     LOGICAL_MINIMUM (0)
  LOGICAL_MAXIMUM(1),  0x01,         //     LOGICAL_MAXIMUM (1)
  REPORT_SIZE(1),      0x01,         //     REPORT_SIZE (1)
  REPORT_COUNT(1),     0x05,         //     REPORT_COUNT (5)
  HIDINPUT(1),         0x02,         //     INPUT (Data, Variable, Absolute) ;5 button bits
  REPORT_SIZE(1),      0x03,         //     REPORT_SIZE (3)
  REPORT_COUNT(1),     0x01,         //     REPORT_COUNT (1)
  HIDINPUT(1),         0x03,         //     INPUT (Constant, Variable, Absolute) ;3 bit padding
  USAGE_PAGE(1),       0x01,         //     USAGE_PAGE (Generic Desktop)
  USAGE(1),            0x30,         //     USAGE (X)
  USAGE(1),            0x31,         //     USAGE (Y)
  USAGE(1),            0x38,         //     USAGE (Wheel)
  LOGICAL_MINIMUM(1),  0x81,         //     LOGICAL_MINIMUM (-127)
  LOGICAL_MAXIMUM(1),  0x7f,         //     LOGICAL_MAXIMUM (127)
  REPORT_SIZE(1),      0x08,         //     REPORT_SIZE (8)
  REPORT_COUNT(1),     0x03,         //     REPORT_COUNT (3)
  HIDINPUT(1),         0x06,         //     INPUT (Data, Variable, Relative) ;3 bytes (X,Y,Wheel)
  USAGE_PAGE(1),       0x0c,         //     USAGE PAGE (Consumer Devices)
  USAGE(2),      0x38, 0x02,         //     USAGE (AC Pan)
  LOGICAL_MINIMUM(1),  0x81,         //     LOGICAL_MINIMUM (-127)
  LOGICAL_MAXIMUM(1),  0x7f,         //     LOGICAL_MAXIMUM (127)
  REPORT_SIZE(1),      0x08,         //     REPORT_SIZE (8)
  REPORT_COUNT(1),     0x01,         //     REPORT_COUNT (1)
  HIDINPUT(1),         0x06,         //     INPUT (Data, Var, Rel)
  END_COLLECTION(0),                 //   END_COLLECTION
  END_COLLECTION(0)                  // END_COLLECTION
};

// PERBAIKAN 1: Hapus fungsi potong string (.substr) yang berbahaya
BleCombo::BleCombo(std::string devName, std::string devManuf, uint8_t batLvl)
    : _buttons(0)
    , hid(0)
    , deviceName(devName)
    , deviceManufacturer(devManuf)
    , batteryLevel(batLvl) {}

void BleCombo::begin(void)
{
  BLEDevice::init(deviceName);
  BLEServer* pServer = BLEDevice::createServer();
  pServer->setCallbacks(this);

  hid = new BLEHIDDevice(pServer);
  inputKeyboard = hid->inputReport(KEYBOARD_ID);  
  outputKeyboard = hid->outputReport(KEYBOARD_ID);
  inputMediaKeys = hid->inputReport(MEDIA_KEYS_ID);
  inputMouse = hid->inputReport(MOUSE_ID);
  outputMouse = hid->outputReport(MOUSE_ID);

  outputKeyboard->setCallbacks(this);
  outputMouse->setCallbacks(this);

  // PERBAIKAN 2: FUNGSI MANUFACTURER DIHAPUS TOTAL KARENA MENYEBABKAN NULL POINTER CRASH
  // hid->manufacturer()->setValue(deviceManufacturer); 

  hid->pnp(0x02, vid, pid, version);
  hid->hidInfo(0x00, 0x01);

#if defined(USE_NIMBLE)
  BLEDevice::setSecurityAuth(true, true, true);
#endif 

  hid->reportMap((uint8_t*)_hidReportDescriptor, sizeof(_hidReportDescriptor));
  hid->startServices();

  onStarted(pServer);

  advertising = pServer->getAdvertising();
  advertising->setAppearance(HID_KEYBOARD);
  advertising->addServiceUUID(hid->hidService()->getUUID());
  
#if !defined(USE_NIMBLE)
  advertising->setScanResponse(false);
#endif
  
  advertising->start();
  hid->setBatteryLevel(batteryLevel);

  ESP_LOGD(LOG_TAG, "Advertising started!");
}

void BleCombo::end(void) {}

bool BleCombo::isConnected(void) {
  return this->connected;
}

void BleCombo::setBatteryLevel(uint8_t level) {
  this->batteryLevel = level;
  if (hid != 0)
    this->hid->setBatteryLevel(this->batteryLevel);
}

void BleCombo::setName(std::string deviceName) {
  this->deviceName = deviceName;
}

void BleCombo::setDelay(uint32_t ms) {
  this->_delay_ms = ms;
}

void BleCombo::set_vendor_id(uint16_t vid) { 
    this->vid = vid; 
}

void BleCombo::set_product_id(uint16_t pid) { 
    this->pid = pid; 
}

void BleCombo::set_version(uint16_t version) { 
    this->version = version; 
}

void BleCombo::sendReport(KeyReport* keys)
{
  if (this->isConnected())
  {
    this->inputKeyboard->setValue((uint8_t*)keys, sizeof(KeyReport));
    this->inputKeyboard->notify();
#if defined(USE_NIMBLE)        
    this->delay_ms(_delay_ms);
#endif 
  } 
}

void BleCombo::sendReport(MediaKeyReport* keys)
{
  if (this->isConnected())
  {
    this->inputMediaKeys->setValue((uint8_t*)keys, sizeof(MediaKeyReport));
    this->inputMediaKeys->notify();
#if defined(USE_NIMBLE)        
    this->delay_ms(_delay_ms);
#endif 
  } 
}

extern const uint8_t _asciimap[128] PROGMEM;
#define SHIFT 0x80
const uint8_t _asciimap[128] =
{
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x2a,0x2b,0x28,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x2c,0x1e|SHIFT,0x34|SHIFT,0x20|SHIFT,0x21|SHIFT,0x22|SHIFT,0x24|SHIFT,0x34,
    0x26|SHIFT,0x27|SHIFT,0x25|SHIFT,0x2e|SHIFT,0x36,0x2d,0x37,0x38,
    0x27,0x1e,0x1f,0x20,0x21,0x22,0x23,0x24,0x25,0x26,
    0x33|SHIFT,0x33,0x36|SHIFT,0x2e,0x37|SHIFT,0x38|SHIFT,
    0x1f|SHIFT,0x04|SHIFT,0x05|SHIFT,0x06|SHIFT,0x07|SHIFT,0x08|SHIFT,0x09|SHIFT,0x0a|SHIFT,
    0x0b|SHIFT,0x0c|SHIFT,0x0d|SHIFT,0x0e|SHIFT,0x0f|SHIFT,0x10|SHIFT,0x11|SHIFT,0x12|SHIFT,
    0x13|SHIFT,0x14|SHIFT,0x15|SHIFT,0x16|SHIFT,0x17|SHIFT,0x18|SHIFT,0x19|SHIFT,0x1a|SHIFT,
    0x1b|SHIFT,0x1c|SHIFT,0x1d|SHIFT,0x2f,0x31,0x30,0x23|SHIFT,0x2d|SHIFT,
    0x35,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10,
    0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1a,0x1b,0x1c,0x1d,
    0x2f|SHIFT,0x31|SHIFT,0x30|SHIFT,0x35|SHIFT,0
};

size_t BleCombo::press(uint8_t k)
{
    uint8_t i;
    if (k >= 136) { k = k - 136; } 
    else if (k >= 128) { _keyReport.modifiers |= (1<<(k-128)); k = 0; } 
    else {
        k = pgm_read_byte(_asciimap + k);
        if (!k) return 0;
        if (k & 0x80) { _keyReport.modifiers |= 0x02; k &= 0x7F; }
    }
    if (_keyReport.keys[0] != k && _keyReport.keys[1] != k &&
        _keyReport.keys[2] != k && _keyReport.keys[3] != k &&
        _keyReport.keys[4] != k && _keyReport.keys[5] != k) {
        for (i=0; i<6; i++) {
            if (_keyReport.keys[i] == 0x00) { _keyReport.keys[i] = k; break; }
        }
        if (i == 6) return 0;
    }
    sendReport(&_keyReport);
    return 1;
}

size_t BleCombo::press(const MediaKeyReport k)
{
    uint16_t k_16 = k[1] | (k[0] << 8);
    uint16_t mediaKeyReport_16 = _mediaKeyReport[1] | (_mediaKeyReport[0] << 8);
    mediaKeyReport_16 |= k_16;
    _mediaKeyReport[0] = (uint8_t)((mediaKeyReport_16 & 0xFF00) >> 8);
    _mediaKeyReport[1] = (uint8_t)(mediaKeyReport_16 & 0x00FF);
    sendReport(&_mediaKeyReport);
    return 1;
}

size_t BleCombo::press(const MouseButton b) {
  buttons(_buttons | b);
    return 1;
}

size_t BleCombo::release(uint8_t k)
{
    uint8_t i;
    if (k >= 136) { k = k - 136; } 
    else if (k >= 128) { _keyReport.modifiers &= ~(1<<(k-128)); k = 0; } 
    else {
        k = pgm_read_byte(_asciimap + k);
        if (!k) return 0;
        if (k & 0x80) { _keyReport.modifiers &= ~(0x02); k &= 0x7F; }
    }
    for (i=0; i<6; i++) {
        if (0 != k && _keyReport.keys[i] == k) { _keyReport.keys[i] = 0x00; }
    }
    sendReport(&_keyReport);
    return 1;
}

size_t BleCombo::release(const MediaKeyReport k)
{
    uint16_t k_16 = k[1] | (k[0] << 8);
    uint16_t mediaKeyReport_16 = _mediaKeyReport[1] | (_mediaKeyReport[0] << 8);
    mediaKeyReport_16 &= ~k_16;
    _mediaKeyReport[0] = (uint8_t)((mediaKeyReport_16 & 0xFF00) >> 8);
    _mediaKeyReport[1] = (uint8_t)(mediaKeyReport_16 & 0x00FF);
    sendReport(&_mediaKeyReport);
    return 1;
}

size_t BleCombo::release(const MouseButton b) {
  buttons(_buttons & ~b);
  return 1;
}

void BleCombo::releaseAll(void)
{
    _keyReport.keys[0] = 0; _keyReport.keys[1] = 0; _keyReport.keys[2] = 0;
    _keyReport.keys[3] = 0; _keyReport.keys[4] = 0; _keyReport.keys[5] = 0;
    _keyReport.modifiers = 0;
    _mediaKeyReport[0] = 0; _mediaKeyReport[1] = 0;
    sendReport(&_keyReport);
  buttons(0);
}

size_t BleCombo::write(uint8_t c) { uint8_t p = press(c); release(c); return p; }
size_t BleCombo::write(const MediaKeyReport c) { uint16_t p = press(c); release(c); return p; }
size_t BleCombo::write(const uint8_t *buffer, size_t size) {
    size_t n = 0;
    while (size--) {
        if (*buffer != '\r') {
            if (write(*buffer)) { n++; } else { break; }
        }
        buffer++;
    }
    return n;
}

void BleCombo::click(const MouseButton b) { buttons(_buttons | b); buttons(_buttons & ~b); }

void BleCombo::move(signed char x, signed char y, signed char wheel, signed char hWheel)
{
  if (this->isConnected())
    {
    uint8_t m[5];
    m[0] = _buttons; m[1] = x; m[2] = y; m[3] = wheel; m[4] = hWheel;
    this->inputMouse->setValue(m, 5);
    this->inputMouse->notify();
#if defined(USE_NIMBLE)
    this->delay_ms(_delay_ms);
#endif 
  }
}

void BleCombo::buttons(const MouseButton b)
{
  if (b != _buttons) { _buttons = b; move(0, 0, 0, 0); }
}

bool BleCombo::isPressed(const MouseButton b) { return ((b & _buttons) > 0); }

void BleCombo::onConnect(BLEServer* pServer) { this->connected = true; }
void BleCombo::onDisconnect(BLEServer* pServer) { this->connected = false; }
void BleCombo::onWrite(BLECharacteristic* me) { }

void BleCombo::delay_ms(uint64_t ms) {
  uint64_t m = esp_timer_get_time();
  if(ms){
    uint64_t e = (m + (ms * 1000));
    if(m > e){ while(esp_timer_get_time() > e) { } }
    while(esp_timer_get_time() < e) {}
  }
}